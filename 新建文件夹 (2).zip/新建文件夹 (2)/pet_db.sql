-- MySQL dump 10.13  Distrib 9.7.1, for Win64 (x86_64)
--
-- Host: localhost    Database: pet_db
-- ------------------------------------------------------
-- Server version	9.7.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED=/*!80000 '+'*/ 'aa16af90-79b1-11f1-abda-d493903654a4:1-22';

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `appointment_time` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `order_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `service_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKg8pohnngqi5x1nask7nff2u7w` (`order_no`),
  KEY `FKm418y0dgaict2akkb9774rcwf` (`service_id`),
  KEY `FK32ql8ubntj5uh44ph9659tiih` (`user_id`),
  CONSTRAINT `FK32ql8ubntj5uh44ph9659tiih` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `FKm418y0dgaict2akkb9774rcwf` FOREIGN KEY (`service_id`) REFERENCES `pet_services` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (1,'2026-07-08 10:00:00.000000','2026-07-07 23:48:21.840822','PET1783439301837CEC2C3',NULL,'待服务','2026-07-07 23:48:21.840822',1,1),(2,'2026-07-08 14:30:00.000000','2026-07-07 23:48:39.637542','PET1783439319637A6926D',NULL,'待服务','2026-07-07 23:48:39.637542',2,1),(3,'2026-07-09 09:00:00.000000','2026-07-07 23:48:51.242945','PET1783439331237F8DA2F',NULL,'待服务','2026-07-07 23:48:51.242945',3,1),(4,'2026-07-09 15:00:00.000000','2026-07-07 23:49:02.561947','PET17834393425611FB699',NULL,'已取消','2026-07-07 23:49:08.519584',4,1),(5,'2026-07-10 11:00:00.000000','2026-07-07 23:49:22.508892','PET1783439362508F00B70',NULL,'待服务','2026-07-07 23:49:22.508892',4,1),(6,'2026-07-10 16:30:00.000000','2026-07-07 23:49:33.477254','PET1783439373477CF9CE1',NULL,'待服务','2026-07-07 23:49:33.477254',5,1),(7,'2026-07-11 10:30:00.000000','2026-07-07 23:49:44.387919','PET1783439384387C8A851',NULL,'待服务','2026-07-07 23:49:44.387919',6,1),(8,'2026-07-11 14:00:00.000000','2026-07-07 23:49:54.820479','PET17834393948203B9430',NULL,'待服务','2026-07-07 23:49:54.820479',7,1),(9,'2026-07-12 15:30:00.000000','2026-07-07 23:50:06.277849','PET1783439406277AD9A29',NULL,'已取消','2026-07-09 09:07:56.706914',8,1);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pet_services`
--

DROP TABLE IF EXISTS `pet_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pet_services` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `available` bit(1) NOT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` int DEFAULT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` decimal(38,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pet_services`
--

LOCK TABLES `pet_services` WRITE;
/*!40000 ALTER TABLE `pet_services` DISABLE KEYS */;
INSERT INTO `pet_services` VALUES (1,_binary '','洗护','包含洗澡、吹干、基础修剪',60,NULL,'标准洗护',88.00),(2,_binary '','洗护','包含SPA、按摩、造型修剪',90,NULL,'精致洗护',168.00),(3,_binary '','寄养','白天托管，含喂食和陪伴',480,NULL,'日间寄养',68.00),(4,_binary '','寄养','过夜托管，含食宿和遛弯',720,NULL,'过夜寄养',128.00),(5,_binary '','疫苗','犬/猫基础疫苗接种',30,NULL,'基础疫苗',120.00),(6,_binary '','疫苗','全面疫苗接种套餐',45,NULL,'全面疫苗',280.00),(7,_binary '','美容','修剪指甲、耳朵清洁',30,NULL,'基础美容',58.00),(8,_binary '','美容','全套美容造型服务',90,NULL,'高级美容',198.00);
/*!40000 ALTER TABLE `pet_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pet_age` int DEFAULT NULL,
  `pet_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pet_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKr43af9ap4edm43mmtq01oddj6` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'2026-07-07 11:28:00.739083','123','123',5,'小蝶','狗','123','2026-07-07 11:28:00.739083','sa');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-09  9:48:19

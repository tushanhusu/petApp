package com.example.pet.service;

import com.example.pet.entity.PetService;
import com.example.pet.repository.PetServiceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PetServiceService {

    private final PetServiceRepository petServiceRepository;

    public List<PetService> findAvailableServices(String category) {
        if (category != null && !category.isEmpty()) {
            return petServiceRepository.findByCategoryAndAvailableTrue(category);
        }
        return petServiceRepository.findByAvailableTrue();
    }
}
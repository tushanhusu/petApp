package com.example.pet.util;

public class IntentParser {
}

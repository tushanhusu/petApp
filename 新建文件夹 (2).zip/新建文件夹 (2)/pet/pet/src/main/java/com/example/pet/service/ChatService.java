package com.example.pet.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.SimpleLoggerAdvisor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class ChatService {

    private final ChatClient chatClient;
    private final PetServiceTools petServiceTools;

    @Value("${spring.ai.deepseek.api-key}")
    private String apiKey;

    public String chat(String userMessage) {
        log.info("收到用户消息: {}", userMessage);

        // 检查 API Key 是否配置
        if (apiKey == null || apiKey.isEmpty() || apiKey.startsWith("${")) {
            log.warn("DeepSeek API Key 未配置，使用模拟回复");
            return getMockReply(userMessage);
        }

        try {
            // 使用真实 AI，并要求返回格式化的回复
            String reply = chatClient.prompt()
                    .system("""
                            你是一个宠物店智能客服助手，回复必须使用以下格式：

                            **回复格式要求：**
                            1. 服务列表使用有序列表（1. 2. 3.），每个服务一行
                            2. 价格用 **¥XX** 突出显示
                            3. 使用 emoji 增加可读性（🐾 💡 ⏰ 💰）
                            4. 分段清晰，每段之间空一行
                            5. 不要使用 Markdown 表格（前端不支持）

                            **示例格式：**
                            🐾 我们提供以下洗护服务：

                            1. 标准洗护 - **¥88**（60分钟）
                               - 包含：洗澡、吹干、基础修剪

                            2. 精致洗护 - **¥168**（90分钟）
                               - 包含：SPA、按摩、造型修剪

                            💡 请问您想预约哪个服务呢？

                            **你的职责：**
                            1. 使用 queryAvailableServices 工具查询服务
                            2. 帮助用户预约服务
                            3. 帮助用户取消预约
                            4. 回答宠物喂养、护理常识、服务规则

                            请用友好、专业的语气回复。
                            """)
                    .user(userMessage)
                    .tools(petServiceTools)
                    .advisors(new SimpleLoggerAdvisor())
                    .call()
                    .content();
            log.info("AI回复: {}", reply);
            return reply;

        } catch (Exception e) {
            log.error("AI调用失败，使用模拟回复", e);
            return getMockReply(userMessage);
        }
    }

    /**
     * 模拟回复 - 备用方案（免费，无需 API）
     */
    private String getMockReply(String userMessage) {
        log.info("使用模拟回复: {}", userMessage);

        if (userMessage.contains("洗护") || userMessage.contains("洗澡")) {
            return "🐾 我们提供以下洗护服务：\n\n" +
                    "1. 标准洗护 - **¥88**（60分钟）\n" +
                    "   - 包含：洗澡、吹干、基础修剪\n\n" +
                    "2. 精致洗护 - **¥168**（90分钟）\n" +
                    "   - 包含：SPA、按摩、造型修剪\n\n" +
                    "3. 深层清洁洗护 - **¥128**（75分钟）\n" +
                    "   - 包含：专业去毛、深度清洁\n\n" +
                    "💡 请问您想预约哪个服务呢？";

        } else if (userMessage.contains("寄养")) {
            return "🏠 我们提供以下寄养服务：\n\n" +
                    "1. 日间寄养 - **¥68/天**（8:00-20:00）\n" +
                    "   - 包含：喂食、陪伴、日常活动\n\n" +
                    "2. 过夜寄养 - **¥128/天**（24小时）\n" +
                    "   - 包含：食宿、遛弯、专人看护\n\n" +
                    "3. 长期寄养 - **¥88/天**（7天起）\n" +
                    "   - 包含：食宿、遛弯、每周洗澡一次\n\n" +
                    "💡 请问您想预约哪种寄养服务？";

        } else if (userMessage.contains("疫苗")) {
            return "💉 我们提供以下疫苗服务：\n\n" +
                    "1. 基础疫苗 - **¥120**（30分钟）\n" +
                    "   - 包含：三针基础免疫\n\n" +
                    "2. 全面疫苗 - **¥280**（45分钟）\n" +
                    "   - 包含：基础免疫 + 狂犬 + 驱虫\n\n" +
                    "3. 加强疫苗 - **¥180**（30分钟）\n" +
                    "   - 包含：年度加强针\n\n" +
                    "💡 请问您想预约哪种疫苗服务？";

        } else if (userMessage.contains("美容")) {
            return "✂️ 我们提供以下美容服务：\n\n" +
                    "1. 基础美容 - **¥58**（30分钟）\n" +
                    "   - 包含：修剪指甲、耳朵清洁\n\n" +
                    "2. 高级美容 - **¥198**（90分钟）\n" +
                    "   - 包含：全套美容造型\n\n" +
                    "3. 精致美容 - **¥298**（120分钟）\n" +
                    "   - 包含：SPA + 造型 + 护理\n\n" +
                    "💡 请问您想预约哪种美容服务？";

        } else if (userMessage.contains("取消")) {
            return "❌ **取消预约流程**\n\n" +
                    "请提供您的订单号，格式：PET + 数字\n" +
                    "（例如：PET20260707123456）\n\n" +
                    "⚠️ 注意：\n" +
                    "- 已完成的服务无法取消\n" +
                    "- 取消后订单状态将变为「已取消」\n\n" +
                    "💡 请告诉我您的订单号，我帮您取消预约。";

        } else if (userMessage.contains("猫") && userMessage.contains("洗澡")) {
            return "🐱 **猫咪洗澡小贴士**\n\n" +
                    "🛁 **洗澡频率：**\n" +
                    "   - 短毛猫：每 3-6 个月洗一次\n" +
                    "   - 长毛猫：每 1-2 个月洗一次\n\n" +
                    "🌡️ **水温控制：**\n" +
                    "   - 最佳温度：38-40 度\n" +
                    "   - 使用宠物专用沐浴露\n\n" +
                    "💡 **温馨提示：**\n" +
                    "   - 洗后立即吹干，避免着凉\n" +
                    "   - 注意耳朵防水\n\n" +
                    "需要我帮您预约洗护服务吗？";

        } else if (userMessage.contains("狗") && userMessage.contains("洗澡")) {
            return "🐶 **狗狗洗澡小贴士**\n\n" +
                    "🛁 **洗澡频率：**\n" +
                    "   - 建议每 2-4 周洗一次\n\n" +
                    "🌡️ **水温控制：**\n" +
                    "   - 最佳温度：36-40 度\n" +
                    "   - 使用宠物专用香波\n\n" +
                    "💡 **温馨提示：**\n" +
                    "   - 注意耳朵防水\n" +
                    "   - 彻底吹干防止皮肤病\n\n" +
                    "需要我帮您预约洗护服务吗？";

        } else if (userMessage.contains("订单") || userMessage.contains("预约")) {
            return "📋 **关于预约和订单**\n\n" +
                    "📌 预约流程：\n" +
                    "   1. 在「服务查询」页面选择服务\n" +
                    "   2. 选择预约日期和时间\n" +
                    "   3. 确认预约信息\n" +
                    "   4. 系统自动生成订单\n\n" +
                    "📋 查看订单：\n" +
                    "   - 点击导航栏「我的订单」\n" +
                    "   - 可查看所有历史订单\n" +
                    "   - 可取消「待服务」状态的订单\n\n" +
                    "💡 需要我帮您预约服务吗？";

        } else if (userMessage.contains("你好") || userMessage.contains("hello") || userMessage.contains("hi")) {
            return "🐾 **你好！我是AI智慧宠物店客服助手！**\n\n" +
                    "我可以帮您：\n" +
                    "   🔍 查询服务（洗护、寄养、疫苗、美容）\n" +
                    "   📅 预约服务\n" +
                    "   ❌ 取消预约\n" +
                    "   💡 回答宠物养护问题\n\n" +
                    "您可以这样问我：\n" +
                    "   → 「我想看看有哪些洗护服务」\n" +
                    "   → 「我想预约寄养」\n" +
                    "   → 「猫咪多久洗一次澡比较好？」\n\n" +
                    "请问有什么可以帮助您的？";

        } else {
            return "🐾 **我是AI智慧宠物店客服助手！**\n\n" +
                    "我可以帮您：\n" +
                    "   🔍 查询服务（洗护、寄养、疫苗、美容）\n" +
                    "   📅 预约服务\n" +
                    "   ❌ 取消预约\n" +
                    "   💡 回答宠物养护问题\n\n" +
                    "📌 您可以这样问我：\n" +
                    "   → 「我想看看有哪些洗护服务」\n" +
                    "   → 「我想预约寄养」\n" +
                    "   → 「猫咪多久洗一次澡比较好？」\n\n" +
                    "请问有什么可以帮助您的？";
        }
    }
}
package com.example.pet.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    @Column(nullable = false)
    private String password;  // 实际项目应加密存储

    @Column(nullable = false)
    private String name;

    private String phone;

    private String petName;
    private String petType;   // 猫/狗/其他
    private Integer petAge;

    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
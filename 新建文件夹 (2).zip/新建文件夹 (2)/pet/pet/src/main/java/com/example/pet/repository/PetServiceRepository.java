package com.example.pet.repository;

import com.example.pet.entity.PetService;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PetServiceRepository extends JpaRepository<PetService, Long> {
    List<PetService> findByCategoryAndAvailableTrue(String category);
    List<PetService> findByAvailableTrue();
}
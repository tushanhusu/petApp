package com.example.pet.service;

import com.example.pet.entity.Order;
import com.example.pet.entity.PetService;
import com.example.pet.entity.User;
import com.example.pet.repository.OrderRepository;
import com.example.pet.repository.PetServiceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class OrderService {

    private final OrderRepository orderRepository;
    private final PetServiceRepository petServiceRepository;

    @Transactional
    public Order createOrder(User user, Long serviceId, LocalDateTime appointmentTime) {
        // 1. 查找服务
        PetService service = petServiceRepository.findById(serviceId)
                .orElseThrow(() -> new RuntimeException("服务不存在"));

        // 2. 校验服务是否可预约
        if (!service.getAvailable()) {
            throw new RuntimeException("该服务当前不可预约");
        }

        // 3. 校验预约时间（不能是过去时间）
        if (appointmentTime.isBefore(LocalDateTime.now())) {
            throw new RuntimeException("预约时间不能是过去时间");
        }

        // 4. 生成订单号
        String orderNo = "PET" + System.currentTimeMillis()
                + UUID.randomUUID().toString().substring(0, 6).toUpperCase();

        // 5. 创建订单实体
        Order order = new Order();
        order.setOrderNo(orderNo);
        order.setUser(user);
        order.setPetService(service);
        order.setAppointmentTime(appointmentTime);
        order.setStatus("待服务");
        order.setCreatedAt(LocalDateTime.now());
        order.setUpdatedAt(LocalDateTime.now());

        // 6. 保存到数据库
        return orderRepository.save(order);
    }

    public List<Order> getUserOrders(User user) {
        return orderRepository.findByUserOrderByCreatedAtDesc(user);
    }

    @Transactional
    public Order cancelOrder(Long orderId, User user) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("订单不存在"));

        if (!order.getUser().getId().equals(user.getId())) {
            throw new RuntimeException("无权操作该订单");
        }

        if ("已完成".equals(order.getStatus())) {
            throw new RuntimeException("已完成的服务无法取消");
        }

        if ("已取消".equals(order.getStatus())) {
            throw new RuntimeException("订单已取消，请勿重复操作");
        }

        order.setStatus("已取消");
        order.setUpdatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }
}
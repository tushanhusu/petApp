package com.example.pet.controller;

import com.example.pet.dto.ChatRequest;
import com.example.pet.dto.ChatResponse;
import com.example.pet.service.ChatService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/chat")
@RequiredArgsConstructor
public class ChatController {

    private final ChatService chatService;

    @PostMapping
    public ChatResponse chat(@RequestBody ChatRequest request) {
        String reply = chatService.chat(request.getMessage());
        return new ChatResponse(reply);
    }

    // 添加 GET 方法用于测试
    @GetMapping
    public ChatResponse chatGet(@RequestParam String message) {
        String reply = chatService.chat(message);
        return new ChatResponse(reply);
    }
}
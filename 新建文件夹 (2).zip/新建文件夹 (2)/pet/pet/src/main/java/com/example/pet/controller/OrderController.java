package com.example.pet.controller;

import com.example.pet.entity.Order;
import com.example.pet.entity.User;
import com.example.pet.service.OrderService;
import jakarta.servlet.http.HttpSession;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@Controller
@RequestMapping("/orders")
@RequiredArgsConstructor
public class OrderController {

    private final OrderService orderService;

    // 返回订单页面
    @GetMapping
    public String ordersPage() {
        return "orders";
    }

    // 返回订单列表 JSON
    @GetMapping("/list")
    @ResponseBody
    public List<Order> listOrders(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return List.of();
        }
        return orderService.getUserOrders(user);
    }

    // ✅ 创建订单
    @PostMapping("/create")
    public String createOrder(
            HttpSession session,
            @RequestParam Long serviceId,
            @RequestParam String appointmentTime
    ) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }

        try {
            // 将字符串转换为 LocalDateTime
            LocalDateTime time = LocalDateTime.parse(appointmentTime);
            orderService.createOrder(user, serviceId, time);
        } catch (Exception e) {
            e.printStackTrace();
            // 可以添加错误信息到 Model 或重定向到错误页
        }

        // 预约成功后重定向到订单列表页面
        return "redirect:/orders";
    }

    // 取消订单
    @PostMapping("/cancel/{orderId}")
    public String cancelOrder(HttpSession session, @PathVariable Long orderId) {
        User user = (User) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        try {
            orderService.cancelOrder(orderId, user);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "redirect:/orders";
    }
}
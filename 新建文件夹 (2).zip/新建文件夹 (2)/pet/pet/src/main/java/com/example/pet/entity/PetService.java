package com.example.pet.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "pet_services")
public class PetService {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;           // 服务名称：洗护、寄养、疫苗、美容

    @Column(nullable = false)
    private String category;       // 服务分类

    private String description;

    @Column(nullable = false)
    private BigDecimal price;

    private Integer duration;      // 服务时长（分钟）

    @Column(nullable = false)
    private Boolean available;     // 是否可预约

    private String imageUrl;
}
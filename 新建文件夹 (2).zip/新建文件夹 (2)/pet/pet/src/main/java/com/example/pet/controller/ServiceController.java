package com.example.pet.controller;

import com.example.pet.entity.PetService;
import com.example.pet.service.PetServiceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;  // ✅ 用 Controller 而不是 RestController
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

@Controller  // ✅ 返回视图
@RequestMapping("/services")
@RequiredArgsConstructor
public class ServiceController {

    private final PetServiceService petServiceService;

    // 返回服务查询页面（Thymeleaf 模板）
    @GetMapping
    public String servicesPage() {
        return "services";  // 返回 templates/services.html
    }

    // 返回服务列表数据（JSON API）
    @GetMapping("/list")
    @ResponseBody  // ✅ 只有这个方法需要返回 JSON
    public List<PetService> listServices(@RequestParam(required = false) String category) {
        return petServiceService.findAvailableServices(category);
    }
}
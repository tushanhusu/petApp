package com.example.pet.dto;

import lombok.Data;

@Data
public class ChatRequest {
    private String message;
}
package com.example.pet.service;

import com.example.pet.entity.PetService;
import com.example.pet.repository.PetServiceRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PetServiceTools {

    private final PetServiceRepository petServiceRepository;

    /**
     * 工具1：查询可预约的宠物服务
     * AI 模型会在用户询问服务时自动调用此方法
     */
    @Tool(description = "查询可预约的宠物服务列表，可按分类筛选（洗护、寄养、疫苗、美容）")
    public List<PetService> queryAvailableServices(
            @ToolParam(description = "服务分类，可选值：洗护、寄养、疫苗、美容，不传则查询全部") String category) {
        if (category != null && !category.isEmpty()) {
            return petServiceRepository.findByCategoryAndAvailableTrue(category);
        }
        return petServiceRepository.findByAvailableTrue();
    }

    /**
     * 工具2：根据ID获取服务详情
     */
    @Tool(description = "根据服务ID获取服务详情，包含价格、时长等信息")
    public PetService getServiceDetail(
            @ToolParam(description = "服务ID") Long serviceId) {
        return petServiceRepository.findById(serviceId).orElse(null);
    }
}